<?php 
    include('./serversql/session.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>
	<?php
		if(isset($_POST['submit'])){
			include('./serversql/conn.php');
			$username = $_SESSION['username'];
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-y h:i:s');
			$query = "insert into bloglist(username,datePosted,blog) values('$username','$date','".mysqli_real_escape_string($conn,htmlspecialchars($_POST['blog']))."');";
			$done = mysqli_query($conn,$query);
			if($done){
				
			}
		}
	?>
	
		<?php
		include_once('./serversql/conn.php');
           $username = $_SESSION['username'];
           $sql = "Select * from bloglist where username='$username'";
           $result = mysqli_query($conn,$sql);
           if ($result->num_rows > 0) {
           		
                  while($row = $result->fetch_assoc()) {
                  	echo "<div class=\"main-frame\">";
                  	echo "<hr>";
                  	echo "<form method=\"post\" action=\"editPost.php\">";
                  	echo "<strong><p id=\"f1\">Post Id #".$row['postnumber']."</p>";
                 	echo "<p id=\"f1\">Date Posted: ".$row['datePosted']."</p></strong>";
                 	echo "<hr>";
                  	echo "<div id=\"f1\">".$row['blog']."</div>";
                  	$blogx = $row['blog'];
                  	echo "<input type=\"hidden\" name=\"xedit\" value=\"".$row['postnumber']."\">";
                  	echo "<br><hr><p id=\"f1\"><button type=\"submit\" name=\"submit\">Edit Blog</button>";
                  	echo "	<button type=\"submit\" name=\"delete\">Delete Blog</button></p>";
                  	echo "<hr>";
                  	echo "</form>";
                  	echo "</div>";
              }
          }
          else
          {
          	echo "<div class=\"main-frame\">";
          	echo "<strong><p id=\"f1\">You have not written any blogs</p></strong>";
          	echo "</div>";

          }
		?>
	
	<?php
		include('./footer.php');
	?>
</body>
</html>