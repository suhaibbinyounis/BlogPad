<?php
	if(isset($_POST['submit'])){
		$newBlog="";
		if(isset($_POST['blogpad']))
		$newBlog = htmlspecialchars($_POST['blogpad']);
		$pnum = $_POST['xedit'];
		$query="update bloglist set blog='$newBlog' where postnumber='$pnum'";
		include('./serversql/conn.php');
		$result=mysqli_query($conn,$query);
		if($result){
			header('location:blogs.php');
		}
	}
	else{
		//echo "<script>document.getElementById('f1').innerHTML = 'POST CANNOT BE UPDATED. TRY AGAIN!';</script>";
	}
	?>