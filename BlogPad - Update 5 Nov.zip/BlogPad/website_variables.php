<?php

	$title = "SBY";
	$logo = "BlogPad";
?>