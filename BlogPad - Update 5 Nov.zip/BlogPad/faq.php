<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>
	<div class="main-frame">
		<h1 id="f1">Welcome to <?include('./website_variables.php'); echo $logo;?></h1>
		<p id="f1">
			FAQ
			<br>
			This page is not yet updated.
		</p>
	</div>


	<?php
		include('./footer.php');
	?>
</body>
</html>