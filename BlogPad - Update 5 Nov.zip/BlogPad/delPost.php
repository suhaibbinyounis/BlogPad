<?php
    include('./serversql/session.php');
	if(isset($_POST['submit'])){
					include('./serversql/conn.php');
					$username = $_SESSION['username'];
					$postnumber=$_POST['xedit'];
					$delQue = "delete from bloglist where username='$username' and postnumber='$postnumber'";
					if(mysqli_query($conn,$delQue)){
						header('location:blogs.php');
					}
				}
?>