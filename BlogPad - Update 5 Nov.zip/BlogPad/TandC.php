<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>
	<div class="main-frame">
		<h1 id="f1">Welcome to <?include('./website_variables.php'); echo $logo;?></h1>
		<p id="f1">
			All your posts are public and visible to anyone who is a member or not of this website.
			<br><br>
			Important instructions:
			<br>
			<ul>
				<li>Be respectful in your writing</li>
				<li>Do not use abusive language</li>
				<li>Your only rights on your content are what is mentioned in FAQ</li>
			</ul>
		</p>
	
	</div>


	<?php
		include('./footer.php');
	?>
</body>
</html>