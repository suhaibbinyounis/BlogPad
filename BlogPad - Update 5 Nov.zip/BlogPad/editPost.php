<?php 
    include('./serversql/session.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>
	<div class="edit_blog" id="update_blog">
			
			
			<?php
			if(isset($_POST['submit'])){
			echo "<form method=\"post\" action=\"temp.php\">";
			echo "<p><strong>There is always room for improvement</strong></p>";
			echo "<textarea value=\"";
			echo isset($_POST['blog'])?$_POST['blog']:'';
			echo "\" id=\"update_text\" name=\"blogpad\" rows=\"30\" cols=\"140\" required>";$username = $_SESSION['username'];if(isset($_POST['submit'])){$xedit = $_POST['xedit'];include_once('./serversql/conn.php');$sql = "Select * from bloglist where username='$username' and postnumber='$xedit';";$result = mysqli_query($conn,$sql);if ($result->num_rows > 0) {
           		while($row = $result->fetch_assoc()){echo $row['blog'];}}}echo "</textarea>";
			echo "<input type=\"hidden\" name=\"xedit\" value=\"".$_POST['xedit']."\">";
			echo "<p><button type=\"submit\" name=\"submit\">Update my blog</button></p>";
			echo "</form>";
			echo "<p><button type=\"button\" onclick=\"goBack()\">Go Back</button></p>";
			}
			else{
				echo "<form method=\"post\" action=\"delPost.php\">";
				echo "<p>Are you sure you want to delete the post?</p>";
				echo "<p>Once deleted, the post cannot be recovered back!</p>";
				echo "<input type=\"hidden\" name=\"xedit\" value=\"".$_POST['xedit']."\">";
				echo "<p><button type=\"submit\" name=\"submit\">Sure Delete</button>";
				echo "	<button type=\"button\" onclick=\"goBack()\">Go Back</button></p>";
				echo "</form>";
				
			}
		?>
	</div>	

	<?php
		include('./footer.php');
	?>
	<script type="text/javascript">
		function goBack() {
  window.history.back();
}	
	</script>
</body>
</html>