<?php
   include('./serversql/conn.php');
   session_start();
   
   $user_check = $_SESSION['username'];
   
   $ses_sql = mysqli_query($conn,"select * from account where username = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['username'];
   $_SESSION['fullname'] = $row['fullname'];
   $_SESSION['email'] = $row['email'];
   
   if(!isset($_SESSION['username'])){
      header("location:login.php");
      die();
   }
?>