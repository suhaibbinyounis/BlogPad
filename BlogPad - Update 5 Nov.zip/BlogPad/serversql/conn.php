<?php
$dbServerName = 'localhost';
$dbUserName = 'root';
$dbPassword = '';
$dbDatabase = 'blog';
$conn = mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbDatabase);
?>