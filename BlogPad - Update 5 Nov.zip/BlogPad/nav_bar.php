<?php
include('./website_variables.php');
echo "<div class=\"nav-bar\">";
		echo "<nav>";
			echo "<ul>";
				echo "<li><h1>".$logo."</h1></li>";
				if(isset($_SESSION['username']))
				echo "<li><a href=\"index.php\"><button><strong>HOME</strong></button></a></li>";
				echo "<li><a href=\"feed.php\"><button><strong>FEED</strong></button></a></li>";
				if(isset($_SESSION['username']))
				echo "<li><a href=\"blogs.php\"><button><strong>MY BLOGS</strong></button></a></li>";
				if(isset($_SESSION['username']))
				echo "<li><a href=\"profile.php\"><button><strong>PROFILE</strong></button></a></li>";
				if(!isset($_SESSION['username']))
				echo "<li><a href=\"login.php\"><button><strong>LOG IN</strong></button></a></li>";
				if(!isset($_SESSION['username']))
				echo "<li><a href=\"signup.php\"><button><strong>SIGN UP</strong></button></a></li>";
				if(isset($_SESSION['username']))
				echo "<li><a href=\"logout.php\"><button><strong>LOG OUT</strong></button></a></li>";
			echo "</ul>";
		echo "</nav>";
	echo "</div>";
	echo "<hr>";
?>