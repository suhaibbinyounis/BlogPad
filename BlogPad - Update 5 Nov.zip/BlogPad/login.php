<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>

	<div class="form">
	<form method="post" action="">
		<table>
			<tr>
				<td><h3>Please <br>Log in to<br> continue...<h3></td>
					<td>
						<a href="./signup.php"><p>Not signed up yet!</p></a>
					</td>
			</tr>
			<tr>
				<td>
					<strong>Username:</strong>
				</td>
				<td>
					<input type="text" name="username" required>
				</td>
			</tr>
			<tr>
				<td>
					<strong>Password:</strong>
					
				</td>
				<td>
					<input type="Password" name="password" required>
				</td>
			</tr>
			<tr>
				<td>
					<button type="submit" name="submit">Log in</button>
				</td>
			</tr>
			<tr>
				<td>
					<p id="error"></p>
				</td>
				<td>
					<p id="errorMsg"></p>
				</td>
			</tr>
		</table>
	</form>
	</div>
	<?php
	if(isset($_POST['submit'])){
		
		$inpUsername = htmlspecialchars($_POST['username']);
		$inpPassword = htmlspecialchars($_POST['password']);

		if(!empty($_POST['username']) && !empty($_POST['password'])){
			include('./serversql/conn.php');
			
			$checkLoginQuery = "select * from account where username='$inpUsername' and password='$inpPassword'";
			$loginQueryResult = mysqli_query($conn,$checkLoginQuery);
			if(mysqli_num_rows($loginQueryResult)> 0){
        		$_SESSION['username'] = $inpUsername;
        		echo "<script>document.getElementById('errorMsg').innerHTML='Logging in...';</script>";
        		   $_SESSION['fullname'] = $row['fullname'];
   				$_SESSION['email'] = $row['email'];
        		echo "<script>window.location.href = \"index.php\";</script>";
    		}
    		else
    		{   
    			echo "<script>document.getElementById('error').innerHTML='Error Message:';</script>";
        		echo "<script>document.getElementById('errorMsg').innerHTML='Invalid Credentials!';</script>";
    		}
		
		}
	}
?>
	<?php
		include('./footer.php');
	?>

</body>
</html>