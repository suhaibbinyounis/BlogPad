<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>

	<div class="form" >
	<form method="post" action="">
		<table>
			<tr>
				<td><h3>Please <br>Sign up here...<h3></td>
					<td>
						<a href="./login.php"><p>Signed up already!</p></a>
					</td>
			</tr>
			<tr>
				<td>
					<strong>Username:</strong>
				</td>
				<td>
					<input type="text" name="username">
				</td>
			</tr>
			<tr>
				<td>
					<strong>Full Name:</strong>
				</td>
				<td>
					<input type="text" name="fullname">
				</td>
			</tr>
			<tr>
				<td>
					<strong>Email:</strong>
				</td>
				<td>
					<input type="email" name="email">
				</td>
			</tr>
			<tr>
				<td>
					<strong>Password:</strong>
					
				</td>
				<td>
					<input type="Password" name="password">
				</td>
			</tr>
			<tr>
				<td>
					<strong>Repeat Password:</strong>
					
				</td>
				<td>
					<input type="Password" name="rep_password">
				</td>
			</tr>
			<tr>
				<td>
					<button type="submit" name="submit">Sign up</button>
				</td>
			</tr>
			<tr>
				<td>
					<p id="error"></p>
				</td>
				<td>
					<p id="errorMsg"></p>
				</td>
			</tr>
		</table>
	</form>
	</div>
	<?php
include_once('./serversql/conn.php');
if(isset($_POST["submit"])){  

if(!empty($_POST['email']) && !empty($_POST['password'])) {
        
    $username = htmlspecialchars($_POST['username']);
    $fullname = htmlspecialchars($_POST['fullname']);
    $email=htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);  
    $rep_password = htmlspecialchars($_POST['rep_password']);
        
try {

	$username_check = "SELECT * FROM account where username='$username'";
	$email_check = "SELECT * FROM account where email='$email'";
    if(mysqli_num_rows(mysqli_query($conn,$username_check))>0)
    {
       # user already exits 
    	echo "<script>document.getElementById('error').innerHTML='Error:'</script>";
        echo "<script>document.getElementById('errorMsg').innerHTML='You are already signed up.<br>Please <a href=\"login.php\">log in</a>.';</script>";
    }
    else if(mysqli_num_rows(mysqli_query($conn,$email_check))>0)
    {
       # user already exits 
    	echo "<script>document.getElementById('error').innerHTML='Error:'</script>";
        echo "<script>document.getElementById('errorMsg').innerHTML='You are already signed up.<br>Please <a href=\"login.php\">log in</a>.';</script>";
    }
    else{
            if($password == $rep_password){
            $sql = "INSERT INTO account VALUES('$username','$fullname','$email','$password');";
            if(mysqli_query($conn,$sql)){
                echo "<script>document.getElementById('error').innerHTML='Success:';</script>";
                echo "<script>document.getElementById('errorMsg').innerHTML='Account creation successfull.<br>Please <a href=\"login.php\">log in</a> to proceed.';</script>";
            }
            }
            elseif($pass!=$rep_pass){
            	echo "<script>document.getElementById('error').innerHTML='Error:';</script>";
                echo "<script>document.getElementById('errorMsg').innerHTML='Password do not match.<br>Please try again.';</script>";
            }
            else{
            	echo "<script>document.getElementById('error').innerHTML='Error:';</script>";
                echo "<script>document.getElementById('errorMsg').innerHTML='Account creation failed.<br>Please try again.';</script>";
            }
    }
} 
catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}   
} 
else {  echo "All fields are required!";  }  
} 
        
?>
	<?php
		include('./footer.php');
	?>

</body>
</html>