<?php
	echo "<div class=\"footer\">";
	echo "<hr>";
	include('./foot_nav_bar.php');
	echo "</div>";
?>