<?php
		echo "<nav>";
			echo "<ul>";
				echo "<li><a href=\"./about.php\"><button><strong>ABOUT</strong></button></a></li>";
				echo "<li><a href=\"./faq.php\"><button><strong>FAQ</strong></button></a></li>";
				echo "<li><a href=\"./TandC.php\"><button><strong>Terms & Conditions</strong></button></a></li>";
			echo "</ul>";
		echo "</nav>";
		echo "<p style=\"text-align:center;\">All Rights Reserved | Suhaib Bin Younis | @suhaibbinyounis</p>";
		echo "<p style=\"text-align:center;\">This is a original work. Please give me credits if you are using this project of mine.</p>";
?>