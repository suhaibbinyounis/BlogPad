<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php include('./website_variables.php'); echo $title;?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include('./nav_bar.php');
	?>
	<?php
		if(isset($_POST['submit'])){
			include('./serversql/conn.php');
			$username = $_SESSION['username'];
			date_default_timezone_set('Asia/Kolkata');
			$date = date('d-m-y h:i:s');
			$blog = $_POST['blog'];
			$query = "insert into bloglist(username,datePosted,blog) values('$username','$date','$blog');";
			if(mysqli_query($conn,$query)){
				echo "<script>document.getElementById('f1').innerHTML='<strong>Your post has been published</strong>';</script>";
			}
		}
	?>
	
		<?php
		include_once('./serversql/conn.php');
           $sql = "Select * from bloglist";
           $result = mysqli_query($conn,$sql);
           if ($result->num_rows > 0) {
           		
                  while($row = $result->fetch_assoc()) {
                  	echo "<div class=\"main-frame\" >";
                  	echo "<hr>";
                  	echo "<strong><p id=\"f1\">Username: ".$row['username']."</p>";
                 	echo "<p id=\"f1\">Date Posted: ".$row['datePosted']."</p></strong>";
                 	echo "<hr>";
                  	echo "<div id=\"f1\">".$row['blog']."</div>";
                  	$blogx = $row['blog'];
                  	echo "<input type=\"hidden\" name=\"xedit\" value=\"".$row['postnumber']."\">";
                  	echo "<hr>";
                  	echo "</div>";
              }
          }
          else
          {
          	echo "<div class=\"main-frame\">";
          	echo "<strong><p id=\"f1\">Very rarely you find no blogs. Guess today is that day...</p></strong>";
          	echo "</div>";

          }
		?>
	
	<?php
		include('./footer.php');
	?>
</body>
</html>