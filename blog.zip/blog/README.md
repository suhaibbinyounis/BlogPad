# Core_php_blog
Informative Blog Created in Core PHP

This PHP web is Core php buildup blog just ready to clone and run on local machine. 
Hosted live on : www.informative.rf.gd
