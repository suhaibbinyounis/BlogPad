</main>
</div>
				<script src="https://code.jquery.com/jquery-3.4.1.min.js"
				integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
				crossorigin="anonymous"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
				<script type="text/javascript" src="/js/jquery.datetimepicker.full.min"></script>
				<script src="/js/script.js"></script>
</body>
</html>
